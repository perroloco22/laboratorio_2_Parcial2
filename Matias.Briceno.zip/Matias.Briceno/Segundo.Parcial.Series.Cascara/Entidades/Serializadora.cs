﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    public class Serializadora : IGuardar<List<Serie>>
    {
        
        public void Guardar(List<Serie> item, string ruta)
        {
            try
            {                
                using (StreamWriter sw = new StreamWriter(ruta))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(List<Serie>));
                    serializer.Serialize(sw, item);
                }
            }
            catch (Exception ex)
            {
                throw new BacklogException($"Error en serializar en xml - {ex.Message}");
            }
        }

        void IGuardar<List<Serie>>.Guardar(List<Serie> item, string ruta)
        {
            try
            {
                string json = JsonSerializer.Serialize(item);
                File.WriteAllText(ruta, json);
            }
            catch (Exception ex)
            {
                throw new BacklogException($"Error en serializar en json - {ex.Message}");
            }
        }
    }
}
