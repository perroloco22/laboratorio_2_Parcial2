﻿using System.ComponentModel;

namespace Entidades
{
    public delegate void DelegadoBacklog(Serie serie);

    public class ManejadorBacklog
    {
        public event DelegadoBacklog NuevaSerieParaVer;
        
        public void IniciarManejador(List<Serie> series)
        {
            Task task = Task.Run(() => MoverSeries(series));
        }

        private void MoverSeries(List<Serie> series)
        {
            while(series.Count != 0)
            {
                Serie serie = series[series.GenerarRandom()];
                series.Remove(serie);
                AccesoDatos.ActualizarSerie(serie);
                Thread.Sleep(1500);
                if (NuevaSerieParaVer is not null)
                {
                    NuevaSerieParaVer.Invoke(serie);
                }
            }
        }
    }
}