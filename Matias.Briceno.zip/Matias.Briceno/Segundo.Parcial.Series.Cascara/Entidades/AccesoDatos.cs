﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class AccesoDatos
    {
        private static SqlCommand command;
        private static SqlConnection connection;
        private static string query;

        static AccesoDatos()
        {
            connection = new SqlConnection(@"Data Source=DESKTOP-LJ7TJ7R\SQLEXPRESS;Initial Catalog=20240701-SP;Integrated Security=True");
            command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.Text;
            query = string.Empty;
        }

        public static void ActualizarSerie(Serie item)
        {
            try
            {
                query = "update series set alumno = @alumno";
                command.CommandText = query;
                command.Parameters.AddWithValue("@alumno", "Matias Briceno Castillo");
                connection.Open();
                command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw new Exception($"Error en la actualizacion de la serie - mensaje: {ex.Message}");
            }
            finally
            {
                connection.Close();
                command.Parameters.Clear();
                query = string.Empty;
            }
        }

        public static List<Serie> ObtenerBackLog()
        {
            List<Serie> series = new List<Serie>();
            try
            {
                query = "select nombre,genero,alumno from series";
                command.CommandText = query;
                connection.Open();
                using (SqlDataReader dr = command.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        series.Add(new Serie(dr.GetString(1),dr.GetString(0)));
                    }
                }
                return series;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error en el metodo backlog: {ex.Message}");
            }
            finally
            {
                connection.Close();
                query = string.Empty;
            }
        }
    }
}
